import threading

def even_num():
	i=0
	cnt=0
	print("First 10 even Numbers")
	while cnt<10:
		if i%2==0:
			print(i,end=' ')
			cnt+=1
		i+=1

def odd_num():
	i=0
	cnt=0
	print("\nFirst 10 odd Numbers")
	while cnt<10:
		if i%2!=0:
			print(i,end=' ')
			cnt+=1
		i+=1


Thread1=threading.Thread(target=even_num,args=())
Thread2=threading.Thread(target=odd_num,args=())

Thread1.start()
Thread2.start()

Thread1.join()
Thread2.join()
