import threading 

def fun(n):
	for i in range(n):
		print("b :- ", i)


"""
This is comment what you say..isn't it amazing
"""

def gun(n):
	for i in range(n):
		print("a :- ", i)

def main():
	thread1=threading.Thread(target=fun,args=(5,))
	thread2=threading.Thread(target=gun,args=(8,))
	thread1.start()
	thread1.join()
	thread2.start()
	thread2.join()

if __name__ == '__main__':
	main()