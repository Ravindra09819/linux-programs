x=input("Enter")
print(x)