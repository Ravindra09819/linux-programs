import threading

def even_factor(number):
	j=0
	sum=0
	for j in range(1,number):
		if(number%j==0):
			if j%2==0:
				print(j,end=" ")
				sum=sum+j

	print("Sum of even factors",sum)


def odd_factor(number):
	sum=0
	for j in range(1,number):
		if number%j==0:
			if j%2!=0:
				print(j,end=" ")
				sum=sum+j

	print("Sum of Odd factors",sum)

number=20
Thread1=threading.Thread(target=even_factor,args=(number,))
Thread2=threading.Thread(target=odd_factor,args=(number,))

Thread1.start()
Thread2.start()
Thread1.join()
Thread2.join()
print("Exit from main")
