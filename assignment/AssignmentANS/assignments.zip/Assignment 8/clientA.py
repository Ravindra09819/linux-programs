# Python TCP Client A
import socket 

host = '192.168.137.1'#socket.gethostname() 
#print(host)
port = 2004
BUFFER_SIZE = 2000 
MESSAGE = input("tcpClientA: Enter message/ Enter exit:").encode() 
 
tcpClientA = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
tcpClientA.connect((host, port))

while MESSAGE.decode() != 'exit' or MESSAGE.decode() != 'EXIT':
    tcpClientA.send(MESSAGE)     
    data = tcpClientA.recv(BUFFER_SIZE)
    print (" Client2 received data:", data)
    MESSAGE = input("tcpClientA: Enter message to continue/ Enter exit:").encode()

tcpClientA.close()