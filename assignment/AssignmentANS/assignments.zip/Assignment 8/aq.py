while 1:
	a=(0,0)
	if a:
		print(type(a))
		print("Tum chutiya ho if your answer is else")
	else:
		print("A<B<B<B<C<F<D<S<R<T<G<")
	break