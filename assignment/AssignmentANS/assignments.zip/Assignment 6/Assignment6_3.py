class Arithmetic():
	def __init__(self):
		self.value1=0
		self.value2=0

	def accept(self):
		self.value1=int(input("Enter 1st number\n"))
		self.value2=int(input("Enter 2nd number\n"))

	def addition(self):
		return (self.value1 + self.value2)

	def substraction(self):
		return (self.value1 - self.value2)

	def multiplication(self):
		return (self.value1 * self.value2)

	def division(self):
		return (self.value1 / self.value2)


obj=Arithmetic()
obj.accept()
print(obj.addition())
print(obj.substraction())
print(obj.multiplication())
print(obj.division())

