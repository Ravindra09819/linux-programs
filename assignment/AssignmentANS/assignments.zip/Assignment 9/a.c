#include<stdio.h>
#include<stdlib.h>

typedef struct node
{
	int data;
	struct node *next;
}node;

/*typedef struct process
{
	int bt;
	int at;
}*/

node *front,*rear;

void init()
{
	front=rear=NULL;
}

void add(int data)
{
	node *newnode;
	newnode=(node *)malloc(sizeof(node));
	newnode->next=NULL;
	newnode->data=data;
	if(rear==NULL)
	{
		rear=newnode;
		rear->next=rear;
		front=rear;		
	}
	else
	{
		rear->next=newnode;
		rear=newnode;
		rear->next=front;
	}
}

int remove1()
{
	int data;
	struct node *temp=front,*temp1=front;
	while(1)
	{
		if(temp->next==front)
		{
			break;
		}
		temp=temp->next;
	}
	data=front->data;
	front=front->next;
	temp->next=front;
	free(temp1);
	return data;
}

int isempty()
{
	return (front==NULL);
}

void display()
{
	struct node *temp=front;
	int z=0;
	while(1)
	{
		printf("%d-> ",temp->data);
		if(temp->next==front)
		{
			if(z==0)
			{
				z=1;
			}
			else
			{
				break;
			}
		}
		temp=temp->next;
	}
}

int main()
{
	int ch,element,n,i;
	int *cpuburst;
	init();
	/*do
	{
	printf("\n 1. Add Element \n 2. Remove Element \n 3. Display elements \n 4. Exit \n Enter Your choice \n");
	scanf("%d",&ch);
	switch(ch)
	{
		case 1:
				printf("\n Enter Element \n");
				scanf("%d",&element);
				add(element);
			break;
			
		case 2:
			if(isempty())
			{
				printf("\n Queue is empty already \n");
			}
			else
			{
				element=remove1();
				printf("\nRemoved Element => %d ",element);
			}
			break;
			
		case 3:
			display();
			break;
			
		case 4:
			exit(0);
			
		default:
			printf("\n Invalid choice \n");
		}
	}while(ch!=4);*/
	int flag;
	printf("\nHow Many Processes");
	scanf("%d",&n);
	int TQ=2;
	cpuburst=(int *)malloc(sizeof(int)*n);
	for(i=0;i<n;i++)
	{
		add(i);
		printf("\n Enter Burst time of process %d",i+1);
		scanf("%d",&cpuburst[i]);
	}
	while(1)
	{
		i=remove();
		printf("process %d ",i);
		if(cpuburst[i]>2)
		{
			cpuburst[i]=cpuburst[i]-2;
			if(cpuburst[i]>0)
				flag=0;
		}
		else
		{
			cpuburst[i]=0;
		}

		if(flag==0)
			add(i);
	}
}