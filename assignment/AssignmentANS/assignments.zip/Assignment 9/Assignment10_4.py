import os,shutil,sys


def copy1(dir1,dir2,ext):
	flag=os.path.isabs(dir1)
	if flag==False:
		dir1=os.path.abspath(dir1)

	if os.path.isdir(dir2):
		print("\n Destination directory already exists \n")
	else:
		os.mkdir(dir2)
		print("New Directory Created\n")

	z=0
	list1=os.listdir(dir1)
	for files in list1:
		full_file_name=os.path.join(dir1,files)
		if(os.path.isfile(full_file_name)):
			if full_file_name.endswith(ext):
				print(full_file_name ," is copied")
				shutil.copy(full_file_name,dir2)
				z=1
	if z==0:
		print("Not a single file found ending with given extension\n")



def main():
	print("\n\n +++++  ==   APPLICATION NAME == +++++ \n")
	print("\t ",sys.argv[0])
	if(len(sys.argv)<1):
		print("\n Invalid Arguments \n")
		exit()

	elif (sys.argv[1]=='-h') or (sys.argv[1]=='-H'):
		print("Application Copies files from one directory to Another directory having some particular extension \n")
		exit()

	elif (sys.argv[1]=='u') or (sys.argv[1]=='U'):
		print("\n Application Usage \n")
		print(" Application_Name arg1 arg2 arg3")
		exit()

	else:
		try:
			copy1(sys.argv[1],sys.argv[2],sys.argv[3])
		except Exception as e:
			print("Application Error as : -    ",e)

if __name__=="__main__":
	main()