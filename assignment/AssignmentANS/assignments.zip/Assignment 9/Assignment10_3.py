import os
import sys
import shutil

def DirectoryFetcher(dir1,dir2):
	flag=os.path.isabs(dir1)
	if flag==False:
		dir1=os.path.abspath(dir1)
	if os.path.isdir(dir2):
		print("No Need To create directory\n")
	else:
		os.mkdir(dir2)
		print("Directory created Successfully\n")
	#dir2=os.path.abspath(dir2)
	arr=os.listdir(dir1)
	z=0
	for files in arr:
		full_file_name=os.path.join(dir1,files)
		if(os.path.isfile(full_file_name)):
			shutil.copy(full_file_name,dir2)
			z=1
	if z==1:
		print("Files Copied Successfully")
	else:
		print("Fuck")



def main():
	print("\n\n\n++++++++----------------++++++++++\n\n")
	print("\nApplication Name is :- ",sys.argv[0])
	if(len(sys.argv)!=3):
		print("Invalid Arguments")
		exit()

	elif (sys.argv[1]=='-h'):
		print("The Application is Defining Directories and Files inside them.....\n")
		exit()

	elif(sys.argv[1]=='-u'):
		print("It must display The Applicationn usage.......\n")
		exit()

	else:
		try:
			DirectoryFetcher(sys.argv[1],sys.argv[2])
		except Exception as e:
			print("Error _ as \t ",e)

if __name__=="__main__":
	main()