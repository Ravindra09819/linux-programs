x=input("Enter File Name\n")

fd=open(x,"r")
print(fd.read())