import os
import sys

def DirectoryFetcher(name,ext):
	z=0
	flag=os.path.isabs(name)
	if(flag==False):
		name=os.path.abspath(name)
	exists=os.path.isdir(name)
	if exists:
		for folder,subfolder,files in os.walk(name):
			print("Folder Name ",folder)
			for f in files:
				if(f.endswith(ext)):
					z=1
					print("File name Is :- ",f)
			print(" ")
			if(z==0):
				print("No Files with given extension found in folder",folder)
			print("\n")

			z=0

	else :
		print("\n Path Not Found")


def main():
	print("\n\n\n++++++++----------------++++++++++\n\n")
	print("\nApplication Name is :- ",sys.argv[0])
	if(len(sys.argv)!=3):
		print("Invalid Arguments")
		exit()

	elif (sys.argv[1]=='-h'):
		print("The Application is Defining Directories and Files inside them.....\n")
		exit()

	elif(sys.argv[1]=='-u'):
		print("It must display The Applicationn usage.......\n")
		exit()

	else:
		try:
			DirectoryFetcher(sys.argv[1],sys.argv[2])
		except Exception as e:
			print("Error _ as \t ",e)

if __name__=="__main__":
	main()