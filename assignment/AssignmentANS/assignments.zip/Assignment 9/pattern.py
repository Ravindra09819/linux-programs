import os
import sys

def fun():
	#Logic

def main():
	print("**-**-**-**-**-**-**-**-**-**-**-**-**")
	print("\nApplication Name is :- ",sys.argv[0])
	if(len(sys.argv)!=2):
		print("Invalid Arguments")
		exit()

	elif (sys.argv[1]=='-h'):
		print("The Application is Defining Directories and Files inside them.....\n")
		exit()

	elif(sys.argv[1]=='-u'):
		print("It must display The Applicationn usage.......\n")
		exit()

	else:
		try:
			fun(sys.argv[1])
		except Exception as e:
			print("Error _ as \t ",e)

if __name__=="__main__":
	main()