

def check(x):
	if x%5==0:
		return "true";
	else:
		return "false";


print("Enter a number")
x=input()
x=int(x)
y=str(check(x))
print(y)
