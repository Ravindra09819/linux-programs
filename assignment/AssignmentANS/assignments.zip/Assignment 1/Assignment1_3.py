def addNum(x,y):
	return (x+y);





print("Enter 2 numbers")
x=input()
y=input()
p=addNum(int(x),int(y))
print("answer is",p)