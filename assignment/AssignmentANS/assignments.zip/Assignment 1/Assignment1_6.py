print("Enter a number")
x=input()
x=int(x)
if x>0:
	print(x,"is positive")
elif x<0:
	print(x,"is negative")
else:
	print(x,"= 0")