def fun():
	print("Hello from fun")

fun()