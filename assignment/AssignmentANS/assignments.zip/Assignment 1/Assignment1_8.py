
def fun():
	print("Enter a number")
	x=int(input())
	for i in range (0,x):
		print('*')

fun()