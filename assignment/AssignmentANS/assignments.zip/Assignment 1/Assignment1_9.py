a=0
i=0
while i<50:
	if a%2==0:
		i=i+1;
		print(a)
	a=a+1

