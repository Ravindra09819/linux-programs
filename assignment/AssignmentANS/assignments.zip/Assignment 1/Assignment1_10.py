print("Enter a string")
x=str(input())
cnt=0
for i in x:
	cnt=cnt+1

print("count =",cnt)