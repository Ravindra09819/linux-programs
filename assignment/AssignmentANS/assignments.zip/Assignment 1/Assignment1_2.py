def chknum(num):
	if num%2==0:
		print("Number is even")
	else :
		print("number is odd");


print("Enter a number")
x=input()
chknum(int(x))
