x=input("How many numbers you want in list \n")

arr=list()

for i in range(int(x)):
	no=input("Enter {} number\n".format(i))
	print(no," is appended\n")
	arr.append(int(no))

print("Elements of list :- ",arr)

max=0
for i in arr:
	if(i > max):
		max=i


print("Maximum number is ",max)