def chkprime(no):
	for i in range(2,int(no/2)+1):
		if(no%i==0):
			return -1

	return 1