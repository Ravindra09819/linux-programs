x=input("How many numbers you want in list \n")

arr=list()

for i in range(int(x)):
	no=input()
	print(no," is appended")
	arr.append(int(no))

print("Elements of list :- ",arr)


sum=0
for i in arr:
	sum=sum+i

print("Addition of numbers in list is :- ",sum)