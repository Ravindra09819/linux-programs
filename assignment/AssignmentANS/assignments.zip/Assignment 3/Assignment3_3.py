x=input("How many numbers you want in list \n")

arr=list()

for i in range(int(x)):
	no=input()
	print(no," is appended")
	arr.append(int(no))

print("Elements of list :- ",arr)

min=0
for i in arr:
	if(i < min):
		min=i


print("Minimum number is ",min)