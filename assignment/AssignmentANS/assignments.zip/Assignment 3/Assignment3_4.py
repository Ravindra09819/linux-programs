x=input("How many numbers you want in list \n")

arr=list()

for i in range(int(x)):
	no=input()
	print(no," is appended")
	arr.append(int(no))

print("Elements of list :- ",arr)

num=input("Enter number that you want to search in the list")

cnt=0
for i in arr:
	if(i==int(num)):
		cnt=cnt+1;

print(" number Found {} Times".format(cnt))