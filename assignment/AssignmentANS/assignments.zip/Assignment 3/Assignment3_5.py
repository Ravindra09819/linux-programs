import MarvellousNum



x=input("How many numbers you want in list \n")

arr=list()

for i in range(int(x)):
	no=input()
	print(no," is appended")
	arr.append(int(no))

print("Elements of list :- ",arr)

def ListPrime(arr):
	sum=0
	for i in arr:
		x=MarvellousNum.chkprime(i)
		if(x==1):
			print(i,end=" ")
			sum=sum+i
	return sum
	
ans=ListPrime(arr)
print("Addition of prime numbers is :- ", ans)