def permutation(str):
	l=len(str)
	for i in str:
		for j in str:
			for k in str:
				print(i,end='')
				print(j,end='')
				print(k,end=' ')

permutation("ABCD")
