def fun(str):
	cnt=0
	for i in str:
		cnt=cnt+1

	return cnt

x=input("Enter a string \n")
print(fun(x))