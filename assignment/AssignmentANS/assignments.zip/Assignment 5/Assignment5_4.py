def fun(str,pos):
	l=len(str)
	i=0
	while(i<=l):
		if(i==pos):
			print("inside\nreplaced \n")
			str.replace(str[i],"")
		i=i+1

	print(str)

fun("SACHIN",3)

