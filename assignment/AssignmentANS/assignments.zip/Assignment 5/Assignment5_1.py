x=input("Enter a string\n")

def fun(str):
	sum=0
	cnt=0
	for i in str:
		#print(ord(i))
		cnt=cnt+1
		sum=sum+ord(i)

	avg=sum/cnt
	return avg

ans=fun(x)
print("Average value:- ",ans)