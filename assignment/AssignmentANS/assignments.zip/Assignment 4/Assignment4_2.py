mult=lambda no1,no2:no1*no2

x=input("Enter a number \n")
y=input("Enter a number\n")
print(mult(int(x),int(y)))