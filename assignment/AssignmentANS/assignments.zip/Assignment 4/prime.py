primes=[10,35,33,89,95,86,29,23,41,46,49]
for j in primes:
	for i in range(2,int(j/2)):
		primes=list(filter(lambda x:x==i or x%i ,primes))# Algorithm includes i but excludes multiples of i

print(primes)