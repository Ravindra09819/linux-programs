import os

os.system('python assignment4_1.py 10')