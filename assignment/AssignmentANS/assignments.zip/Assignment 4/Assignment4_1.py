import sys

pow=lambda no: 2**no

#x=int(input("Enter a number\n\n"))
print("Power of 2^{} = ".format(int(sys.argv[1])),pow(int(sys.argv[1])))