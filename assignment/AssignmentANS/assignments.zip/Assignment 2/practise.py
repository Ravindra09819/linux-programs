#      Use of Global 

#p=285
#print(p)
#print(id(p))
#def fun():
	
	
#	global p
#	p=22

#	print(p)
#	print(id(p))


#fun()
#print(p)
#print(id(p))


#		Dynamic List

#x=input("How many numbers do you want to add in the list")
#arr=list()

#for i in range (int(x)):
#	no=input()
#	arr.append(int(no))

#print("List elements are :- ",arr)



#    	TYpes of Parameters


#keyword parameter
#def fun(name,age,school):
#	print("Name is :- ",name,end=' ')
#	print("and Age is ",age,end=' ')
#	print("and School is ",school,end=' ')

#fun(school="VIT",name="Pearce",age=20)


# Variable number of arguments

#def fun(*no):
#	ans=0
#	for i in no:
#		ans=ans+i

#	return ans

#t1=fun(10,20,30,50)
#print(t1)

#t2=fun(1,1,2,3,5,4,8,5,84,81,87,44,55)
#print(t2)
#
#t3=fun(101,122,152,141,1002)
#print(t3)


#Variable keyword arguments

#def fun(**other):
#	for i,j in other.items():
#		print(i,j)

#fun(name="sachin",age="22",relation="student")
#fun(num1=10,num2=22,name="mayur",age="10",talent="gold_medalist")

#   ANONYMOUS FUNCTION          */
#fp=lambda no1,no2,no3,no4 : (no1+no2*no3/no4)

#ret=fp(1,5,6,10)
#print("Value is :- ",ret)

# 		 FILTER-MAP-REDUCE METHOD

#from functools import reduce
#arr=[10,15,22,26,25,84,86,66,36,30,25,41,15,19,22,20]

#Evenarr=list(filter(lambda no:(no%2==0),arr))
#print(Evenarr)

#Evenarr_map=list(map(lambda no:(no*2),Evenarr))
#print(Evenarr_map)


#Answer=reduce(lambda no1,no2:(no1+no2),Evenarr_map)

#print(Answer)


#		 OBJECT ORIENTED PYTHON
#class demo:
#	x=10.15
#	y="SAchin"
#
#	def __init__(self,no1,name):
#		self.name=name
#		self.x=no1

#print(demo.x)
#print(demo.y)

#obj=demo(10.22,"kulawade")
#print(obj.y)
#print(obj.x)
#print(obj.name)
#   USE OF STATIC , CLASS AND INSTANCE METHODS
#class demo:
#	x=10.15
#	y="SAchin"

#	def __init__(self,no1,name):
#		self.name=name
#		self.x=no1
#print(demo.x)
#print(demo.y)
#obj=demo(10.22,"kulawade")
#print(obj.y)
#print(obj.x)
#print(obj.name)
#class demo:
#	def fun(self):
#		print("Inside instance method")
#
#	@classmethod
#	def gun(cls):
#		print("Inside class method")
#
#	@staticmethod
##	def sun():
#		print("Inside static method")
#
#obj=demo()
#obj.fun()


#demo.gun()
#demo.sun()


#    DECORATORS

#def sub(a,b):
#	print("Substraction is ",a-b)

#def smart_sub(fptr):
#	def inner(a,b):
#		if a<b:
#			a,b=b,a
#		return fptr(a,b)

#	return inner

#sub=smart_sub(sub)

#sub(7,10)
#sub(10,7)


#    MULTITHREADING
import threading

def fun(number):
	for i in range(number):
		print(i)


def gun(number1):
	for i in range(number1):
		print(i)

number=4
number1=10

Thread1=threading.Thread(target=fun,args=(number,))
Thread2=threading.Thread(target=gun,args=(number1,))


Thread1.start()
Thread2.start()

Thread1.join()
Thread2.join()
print("Exit from main")

