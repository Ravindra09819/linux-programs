def prime(x):
	for i in range(2,int(x/2)):
		if(x%i==0):
			return -1
		i=i+1
	return 1

print("Enter number")
x=int(input())
c=prime(x)

if(c==-1):
	print("Number is not prime")
else:
	print("Number is prime")