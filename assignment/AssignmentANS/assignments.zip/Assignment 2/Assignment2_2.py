print("Enter a number ")
x=int(input())
for i in range(0,x):
	for j in range(0,5):
		print('*',end=" ")

	print("\n")