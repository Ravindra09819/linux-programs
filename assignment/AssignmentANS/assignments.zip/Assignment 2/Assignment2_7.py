def pat(x):
	for i in range(0,x):
		z=1
		for j in range (0,5):
			print(z,end=' ')
			z=z+1
		print("\n")



print("Enter a number ")
x=int(input())
pat(x)