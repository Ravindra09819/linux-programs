def add_factor(x):
	s=0
	for i in range(1,x):
		if x%i==0:
			s=s+i
		i=i+1
	return s

print("Enter number")
x=int(input())
c=int(add_factor(x))
print("Answer is",c)