def pat(x):
	for i in range(x,0,-1):
		for j in range(0,i):
			print("*",end=' ')
		print("\n")

print("Enter a number ")
x=int(input())
pat(x)