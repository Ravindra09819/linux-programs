def noofdigits(n):
	cnt=0
	while n>0:
		cnt=cnt+1;
		n=int(n/10);
	return cnt


print("Enter a number ")
x=int(input())
p=noofdigits(x)
print("No of digits in ",x," are ", p)