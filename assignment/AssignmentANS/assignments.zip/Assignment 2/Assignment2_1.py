import Arithmetic
print("Enter 2 numbers")
x=int(input())
y=int(input())

c=Arithmetic.add(x,y)
print("Addition is =>",c)

c=Arithmetic.sub(x,y)
print("Substraction is =>",c)

c=Arithmetic.mult(x,y)
print("Multiplication is =>",c)

c=float(Arithmetic.div(x,y))
print("Division is=> ",c)
