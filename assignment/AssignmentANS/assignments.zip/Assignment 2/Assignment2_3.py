def fact(x):
	mult=1
	while x>0 :
		mult=mult*x
		x=x-1
	return mult

print("Enter number")
x=int(input())
ans=int(fact(x))
print("Factorial of number is",ans)