def noofdigits(n):
	cnt=0
	while n>0:
		t=n%10
		cnt=cnt+t;
		n=int(n/10);
	return cnt


print("Enter a number ")
x=int(input())
p=noofdigits(x)
print("Sum of digits in ",x," is ", p)