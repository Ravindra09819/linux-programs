class BankAccount:
	ROI = 10.5

	def __init__(self,Name,amt):
		self.name=Name
		self.amount=amt

	def display(self):
		print("\nName :-  ",self.name)
		print("Amount :- ",self.amount)


	def deposit(self,amt):
		self.amount+=amt
		print("After depositing:- ",self.amount)

	def withdraw(self,amt):
		self.amount-=amt
		print("After Withdrawl:- ",self.amount)

	def Calculate(self):
		interest=((self.ROI)*(self.amount))/100
		print("Rate of interest :- ",interest)

obj1=BankAccount("Mayur",15000)
obj1.display()
obj1.Calculate()
obj1.deposit(1000)
obj1.withdraw(2500)
print("\n")
print("After all transactions :- \n")
obj1.display()
print("---------------------------------------------")

obj2=BankAccount("Ramu",40000)
obj2.display()
obj2.Calculate()
obj2.deposit(22000)
obj2.withdraw(15535)
print("\n")
print("After all transactions :- \n")
obj2.display()
print("---------------------------------------------")